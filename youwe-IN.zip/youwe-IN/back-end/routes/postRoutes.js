const express = require('express');
const postRoutes = express.Router();
let Posts = require('../models/post.model');

postRoutes.route('/').get(function(req,res){
    Posts.find(function(err,posts){
        if(err){
            console.log(err);
        }
        else{
            res.json(posts); 
        }
    })
})

postRoutes.route('/add').post(function(req,res){
  let posts = new Posts(req.body);
  posts.save()
  .then(posts =>{
      res.status(200).json({'posts':'post added successfully'})
  })
  .catch(err =>{
      res.status(400).send('adding new post failed');
  
  })
})

postRoutes.route('/delete/:id')
.get(function(req,res){
  Posts.deleteOne({_id:req.params.id},function(err,post){
      if(err) res.json(err);
      else res.json({
          message: 'Successfully removed',
          post:post
      });
  });
});

module.exports = postRoutes;