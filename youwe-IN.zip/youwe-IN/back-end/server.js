const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors'); 
const mongoose = require('mongoose');
const config = require('./config/db');
const profileRoutes = require('./routes/profileRoutes');
const jobRoutes = require('./routes/jobRoutes');
const postRoutes = require('./routes/postRoutes');
const applyRoutes = require('./routes/applyRoutes');
const expressValidator = require('express-validator');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const PORT = 4000;

mongoose.Promise = global.Promise;
mongoose.connect(config.DB,{useNewUrlParser:true}).then(
    ()=>{ console.log("MongoDB database connection established successfully")},
    err =>{console.log('Cannot connect to datbase'+err.stack);}
);

app.use(cors());
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(cookieParser());
// Set Static Folder
app.use(express.static(path.join(__dirname, 'public')));

// Express Session
app.use(session({
    secret: 'secret',
    saveUninitialized: true,
    resave: true
  }));
  
  
  
  // Express Validator
  app.use(expressValidator({
    errorFormatter: function (param, msg, value) {
      var namespace = param.split('.')
        , root = namespace.shift()
        , formParam = root;
  
      while (namespace.length) {
        formParam += '[' + namespace.shift() + ']';
      }
      return {
        param: formParam,
        msg: msg,
        value: value
      };
    }
  }));

let user = require('./routes/userRoutes');
app.use('/profile',profileRoutes);
app.use('/jobs',jobRoutes);
app.use('/posts',postRoutes);
app.use('/users',user);
app.use('/applies',applyRoutes);

app.listen(PORT,function(){
    console.log("Server is running on port:" +PORT);
})