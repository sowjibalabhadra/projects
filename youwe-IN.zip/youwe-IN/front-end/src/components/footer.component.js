import React, { Component } from 'react';
import { Link } from 'react-router-dom'
import '../App.css';
import { Icon } from 'semantic-ui-react';
import Button from 'semantic-ui-react';

export default class Footer extends React.Component {
    render() {
        return (
            <div className="container">
           <h3> <strong>Share via facebook, twitter, whatsapp to your friends:</strong></h3>
                  <button className="ui facebook button">
                <i class="facebook icon"></i>
                <a href="https://www.facebook.com/">Facebook</a>
                </button>
                <button className="ui twitter white button">
                    <i className="twitter icon"></i>
                    <a href="https://twitter.com/login">Twitter</a>
                </button>
                <button class="ui whatsapp green button">
                    <i class="whatsapp icon"></i>
                    <a href="https://whatsappweb.com">Whatsapp</a>
                </button>
                <h4 style={{color: 'green'}}>This website is available for these countries only: </h4>
            <div className="container">
              <div className="row">
                <div className="col-lg-2">
                <div className="ui segment">
                           <i className="in flag"></i>
                           <i className="france flag"></i>
                           <i className="myanmar flag"></i>
                           <i className="pakistan flag"></i>
                           <i className="australia flag"></i>
                        </div>
            </div>
            </div>
            </div>
            </div>
        )

    }
}