import React from 'react';
import NavBar from './nav.component';
import '../App.css';
import Footer from './footer.component';

export default class Home extends React.Component {
    render() {
        return (
            <div>
                <NavBar/>
            
                    <h1 className="text-center " style={{ marginTop: 30 }}> Welcome to YouWe-In</h1>
                    <div className="container" style={{backgroundColor:"#f0e68c"}}>
                    <div className="row">
                        <div className="col-lg-6" style={{ marginTop: 140 }}>
                            <h2 className="text-dark"><i className="fas fa-hand-point-right"></i> This web application is a social networking site
                            designed specifically for the business community. The goal of the site is to allow registered members
                            to establish and document networks of people they know and trust professionally.</h2>
                        </div>
                        <div className="col-lg-6 ">
                        <img src="./images/footer.jpg"  className="img "/></div>
                    </div>
                </div>
                <br/>
                <hr />
                
                <Footer/>
            </div> 

        )
    }
}