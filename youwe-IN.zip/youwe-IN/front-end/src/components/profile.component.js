import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import NavBar2 from './navBar2.component';
import { Button } from 'semantic-ui-react';


export default class Profile extends Component {

    constructor(props) {
        super(props);

        this.state = { profile: [], id: '' };

        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeQualification = this.onChangeQualification.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeRecentlyWorked = this.onChangeRecentlyWorked.bind(this);
        this.onChangeExperience = this.onChangeExperience.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangeContactNumber = this.onChangeContactNumber.bind(this);
        //binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);
        // this.clearForm = this.clearForm.bind(this);
        this.state = {
            firstName: '',
            lastName: '',
            qualification: '',
            recentlyWorked: '',
            experience: '',
            email: '',
            contactNumber: ''


        }



     

    }
    onChangeFirstName(event) {
        this.setState({
            firstName: event.target.value
        });
    }
    onChangeLastName(event) {
        this.setState({
            lastName: event.target.value
        });
    }
    onChangeQualification(event) {
        this.setState({
            qualification: event.target.value
        });
    }
    onChangeRecentlyWorked(event) {
        this.setState({
            recentlyWorked: event.target.value
        });
    }
    onChangeExperience(event) {
        this.setState({
            experience: event.target.value
        });
    }
    onChangeEmail(event) {
        this.setState({
            email: event.target.value
        });
    }
    onChangeContactNumber(event) {
        this.setState({
            contactNumber: event.target.value
        });
    }

    onSubmit(event) {
        event.preventDefault();

        const newProfile = {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            qualification: this.state.qualification,
            recentlyWorked: this.state.recentlyWorked,
            experience: this.state.experience,
            email: this.state.email,
            contactNumber: this.state.contactNumber,
        }
        // //for json server
        // axios.post('http://localhost:4000/products/', newProduct)
        //     .then(res => console.log(res.data));

        //for mongodb
        axios.post('http://localhost:4000/profile/add', newProfile)
            .then(res => console.log(res.data));

        this.setState({
            firstName: '',
            lastName: '',
            qualification: '',
            recentlyWorked: '',
            experience: '',
            email: '',
            contactNumber: ''

        })
        Swal.fire("Added Successful");
        this.props.history.push('/myprofile');
        window.location.reload();
    }

    clearForm(e) {
        e.preventDefault();
        this.setState({
            firstName: '',
            lastName: '',
            qualification: '',
            recentlyWorked: '',
            experience: '',
            email: '',
            contactNumber: ''

        })
    }
    clearForm(e) {
        e.preventDefault()
        this.clear();
    }


    render() {
        return (
<div>

           <NavBar2/>
                <div style={{backgroundColor:"bisque"}}>
                    <div className="row">
                        <div className="offset-lg-1 col-lg-5">
                            <div style={{ marginTop: 10 }}>
                                <h3 className="text-primary">Add Profile</h3><br />
                                <form onSubmit={this.onSubmit} required>

                                    <div className="form-group">

                                        <label><b>First Name </b><span className="required-mark" style={{color:"red"}}>*</span>:</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.firstName}
                                            onChange={this.onChangeFirstName} required />

                                    </div>

                                    <div className="form-group">
                                        <label><b>Last Name</b><span className="required-mark" style={{color:"red"}}>*</span>:</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.lastName}
                                            onChange={this.onChangeLastName} required />
                                    </div>
                                    <div className="form-group">
                                        <label><b>Qualification </b><span className="required-mark" style={{color:"red"}}>*</span>:</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.qualification}
                                            onChange={this.onChangeQualification} required />
                                    </div>
                                    <div className="form-group">
                                        <label><b>Recently Worked </b><span className="required-mark" style={{color:"red"}}>*</span>:</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.recentlyWorked}
                                            onChange={this.onChangeRecentlyWorked} required/>
                                    </div>
                                    <div className="form-group">
                                        <label><b>Experience </b><span className="required-mark" style={{color:"red"}}>*</span>:</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.experience}
                                            onChange={this.onChangeExperience} required />
                                    </div>
                                    <div className="form-group">
                                        <label><b>Email </b><span className="required-mark" style={{color:"red"}}>*</span>:</label>
                                        <input type="email"
                                            className="form-control"
                                            value={this.state.email}
                                            onChange={this.onChangeEmail} required />
                                    </div>
                                    <div className="form-group">
                                        <label><b>Contact Number </b><span className="required-mark" style={{color:"red"}}>*</span>:</label>
                                        <input type="number"
                                            className="form-control"
                                            value={this.state.contactNumber} 
                                            onChange={this.onChangeContactNumber} required/>
                                    </div>






                                    <div className="form-group">
                                        {/* <input type="submit" value="Add Profile"
                                            className="btn btn-success" />&nbsp;&nbsp; */}

<button className="ui green basic button" type="submit" >
        Add Profile
      </button>&nbsp;&nbsp;

                         {/* <button type="button" onClick={this.clearForm}
                                            className="btn btn-danger" >Clear </button>

                                             <button type="button" className="ui red basic button" onClick={this.clearForm}>Clear</button> */}
                                    </div>
                                </form>
                            </div>
                        </div>
                        <br />
                        <div className="col-lg-6" style={{marginTop:"30"}}>
                    <img src="./images/profile1.png "width="300" height="300"/>
                    </div>
                    </div>
                    
                    <hr />
                  
                </div>
                </div>
                )
            }
        }
