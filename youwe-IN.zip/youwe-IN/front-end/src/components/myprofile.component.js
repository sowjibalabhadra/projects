import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import '../App.css';
import NavBar2 from './navBar2.component';


class User extends Component {
    constructor(props) {
        super(props);

        this.deleteUser = this.deleteUser.bind(this);
    }

    deleteUser() {
        let result =
            Swal.fire('Do you want to delete current user?');
        if (result) {
            axios.get('http://localhost:4000/profile/delete/' + this.props.user._id)
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    )
                }
            })
                .then(console.log('Deleted Successfully'))
                .catch(err => console.log(err))
        }
    }

    render() {
        return (
            <div>
                <div className="div-box container ">

           <tr>
                <td><b>First Name:</b> {this.props.user.firstName}</td></tr>
                <tr>
                <td><b>Second Name</b> {this.props.user.lastName}</td></tr>
                <tr>
                <td><b>Qualification: </b> {this.props.user.qualification}</td></tr>
                <tr>
                <td> <b>Recently Worked :</b>{this.props.user.recentlyWorked}</td></tr>
                <tr><td><b>Experience:</b> {this.props.user.experience}</td></tr>
                <tr><td><b>Email:</b>{this.props.user.email}</td></tr>
              <tr>  <td><b>Contadct Number:</b>{this.props.user.contactNumber}</td></tr>

                <td>
                    
                    <Link to={"/edit-profile/" + this.props.user._id} className="btn btn-success" >Edit</Link>
                    &nbsp;  &nbsp;
                    {/* <Link to={"/edit-profile/" + this.props.user._id}  inverted color='blue'>
        Edit
      </Link> */}
                         <button onClick={this.deleteUser} className="btn btn-danger">Delete</button>
                </td>
                </div>
                </div>
        
        )
    }
}
export default class Myprofile extends Component {
    constructor(props) {
        super(props);
        this.state = { profile: [], id: '' };

        // this.onChangeProductName = this.onChangeProductName.bind(this);
        // this.onChangeProductCost = this.onChangeProductCost.bind(this);
        //binding onSubmit event
        // this.onSubmit = this.onSubmit.bind(this);
        // this.clearForm = this.clearForm.bind(this);


    }
    //life cycle hook
    componentDidMount() {
        axios.get('http://localhost:4000/profile')
            .then(response => {
                this.setState({ profile: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    userList() {
        return this.state.profile.map(function (currentUser, i) {
            return <User user={currentUser} key={i} />;
        })
    }

    render() {
        return (
            <div>

          <NavBar2/>

           <div className="container">
                <div className="row">
                    <div className="col-lg-6" style={{ marginTop: 20 }} >
                        <h3 className="text-left text-primary">My Profile </h3>
                        <table className="table table-stripped"
                            style={{ marginTop: 20 }} >
                         
                            <tbody>
                                {this.userList()}

                            </tbody>
                        </table>
                    </div>
                 
              
                </div>
            </div>
          </div> 
    )
    }
}

