import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { Button } from 'semantic-ui-react';
import Myprofile from './myprofile.component';
import { MDBInput } from "mdbreact";
import '../App.css'

class Post extends Component {
    constructor(props) {
        super(props);
        this.deletePost = this.deletePost.bind(this);
    }

    deletePost() {
        let result =
            window.confirm('Do you want to delete current post?');
        if (result) {
            axios.get('http://localhost:4000/posts/delete/' + this.props.post._id)
                .then(console.log('Deleted Successfully'))
                .catch(err => console.log(err))
        }
        window.location.reload();
    }
    // deleteProduct = _id => {
    //     setProducts(products.filter(product => product._id !== _id))
    //   }
    render() {
        return (
            <div>
  
                     <div className="alert alert-primary alert-dismissible">
                <td>{this.props.post.addYourPost}</td>

      
                    <button onClick={this.deletePost} className="btn btn-link" style={{ marginLeft: 600 }}><i class="fas fa-trash-alt"></i></button>

              
                {/* <td>
                         <Link to={"/edit/" + this.props.product._id}>Edit</Link>
                          &nbsp;  &nbsp;
                     <button onClick={this.deleteProduct} className="btn btn-link">Delete</button>
                    </td> */}
            </div>
            </div>
        )
    }
}
export default class postList extends Component {

    constructor(props) {
        super(props);
        this.state = { posts: [], id: '' };

        this.onChangeAddYourPost = this.onChangeAddYourPost.bind(this);

        //binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);



    }
    //life cycle hook
    componentDidMount() {
        axios.get('http://localhost:4000/posts')
            .then(response => {
                this.setState({ posts: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    postList() {

        return this.state.posts.map(function (currentPost, i) {
            return <Post post={currentPost} key={i} />;
        })




    }
    onChangeAddYourPost(event) {
        this.setState({
            addYourPost: event.target.value
        });
    }

    onSubmit(event) {
        event.preventDefault();

        const newPost = {
            addYourPost: this.state.addYourPost
        }
        // //for json server
        // axios.post('http://localhost:4000/products/', newProduct)
        //     .then(res => console.log(res.data));

        //for mongodb
        axios.post('http://localhost:4000/posts/add', newPost)
            .then(res => console.log(res.data));

        this.setState({
            addYourPost: ''


        })
        window.location.reload();
        this.props.history.push('/newsfeed');
    }
    render() {
        return (
            <div className="container-fill ">
                <div className="form-group">
                    <div className="offset-lg-2 col-lg-8">
                        <div style={{ marginTop: 10 }}>
                            <form onSubmit={this.onSubmit}>

                               
                                    <label><i class="fas fa-pencil-alt"></i><b>Write something here...</b>  </label>
                                    {/* <MDBInput
                                        type="textarea"
                                        rows="2"
                                        icon="pencil-alt"
                                        placeholder="Say Something" icon="pencil-alt"
                                        className="form-control"
                                        value={this.state.addYourPost}
                                        onChange={this.onChangeAddYourPost}
                                    /> */}
                                    <textarea   icon="pencil-alt" type="text" placeholder="Share your thoughts & feelings" icon="pencil-alt"
                                        className="form-control colo"
                                        value={this.state.addYourPost}
                                        onChange={this.onChangeAddYourPost} required ></textarea>
          <br/>

                                {/* <div className="form-group"> */}

                                <input type="submit" value="Add Post"
                                        className="btn btn-primary" />&nbsp;&nbsp;

                                {/* </div> */}
                            </form>
                     
                        </div>

                       
                   
                        </div>
                </div>
               <br/>
                <div className="row">
                    <div className="offset-lg-2 col-lg-8">
                        <h3 className="text-center text-primary">Posts List</h3>


                        <div >
                            <button type="button" className="close" onClick={this.postList()} data-dismiss="alert"></button>

                            {this.postList()}
                        </div>



                        {/* </table> */}
                    </div>
                </div>
            </div>
        )
    }
}