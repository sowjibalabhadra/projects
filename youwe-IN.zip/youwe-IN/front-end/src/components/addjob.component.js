import React, { Component } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import NavBar2 from './navBar2.component';
import { Button } from 'semantic-ui-react';
export default class Addjob extends Component {
    constructor(props){
        super(props);

        // binding text box onChange events
        this.onChangeCompanyName=this.onChangeCompanyName.bind(this);
        this.onChangeLocation=this.onChangeLocation.bind(this);
        this.onChangeRole=this.onChangeRole.bind(this);
        this.onChangeSkills=this.onChangeSkills.bind(this);
        this.onChangeExperience=this.onChangeExperience.bind(this);
     
        this.onChangeEmail=this.onChangeEmail.bind(this);
        this.onChangeContactNumber=this.onChangeContactNumber.bind(this);

        // binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
        this.state={
            companyName: '',
            location: '',
            role: '',
            skills:'',
            experience: '',
            email: '',
            contactNumber: '',
        }
    } //end of constructor

    onChangeCompanyName(e){
        this.setState({
            companyName: e.target.value
        });
    }
    onChangeLocation(e){
        this.setState({
            location: e.target.value
        });
    }
    onChangeRole(e){
        this.setState({
            role: e.target.value
        });
        
    }
    onChangeSkills(e){
        this.setState({
            skills: e.target.value
        });
        
    }
    onChangeExperience(e){
        this.setState({
            experience: e.target.value
        });
        
    }
    onChangeEmail(e){
        this.setState({
            email: e.target.value
        });
        
    }
    onChangeContactNumber(e){
        this.setState({
            contactNumber: e.target.value
        });
        
    }


    onSubmit(e){
        e.preventDefault();
        // console.log(this.state.todo_completed);
        const newJob ={
            companyName: this.state.companyName,
            location: this.state.location,
            role: this.state.role,
            skills:this.state.skills,
            experience: this.state.experience,
            email: this.state.email,
            contactNumber: this.state.contactNumber
        };

        axios.post('http://localhost:4000/jobs/add',newJob).then(res => console.log(res.data));

        this.setState({
            companyName: '',
            location: '',
            role: '',
            skills: '',
            experience:'',
            email:'',
            contactNumber:''
        })
       
        
        // redirecting to home component
        this.props.history.push('/newsfeed');
        window.location.reload();
    }// end of onSubmit() function
    clearForm(e){
        e.preventDefault();
        this.setState({
            companyName: '',
            location: '',
            role: '',
            skills: '',
            experience:'',
            email:'',
            contactNumber:''
        })
    }
    render() {
        return (
            <div>
            <NavBar2/>
            <div className="container" style={{backgroundColor:" blanchedalmond"}}>
            <div className="col-lg-6">
                <h3 className="text-info" style={{ marginTop: 30 }}>Publish a new job</h3>
                <hr />
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label><b> Company Name/Business</b><span className="required-mark" style={{color:"red"}}>*</span>: </label>
                        <input type="text" className="form-control" 
                        value={this.state.companyName} onChange={this.onChangeCompanyName} required />
                    </div>
                    <div className="form-group">
                        <label><b> Location</b><span className="required-mark" style={{color:"red"}}>*</span>: </label>
                        <input type="text" className="form-control" 
                        value={this.state.location} onChange={this.onChangeLocation} required />
                    </div>
                    <div className="form-group">
                        <label><b> Role</b><span className="required-mark" style={{color:"red"}}>*</span>: </label>
                        <input type="text" className="form-control" 
                        value={this.state.role} onChange={this.onChangeRole} required />
                    </div>
                    <div className="form-group">
                        <label><b> Skills</b><span className="required-mark" style={{color:"red"}}>*</span>: </label>
                        <input type="text" className="form-control" 
                        value={this.state.skills} onChange={this.onChangeSkills} required />
                    </div>
                    <div className="form-group">
                        <label><b> Experience</b><span className="required-mark" style={{color:"red"}}>*</span>: </label>
                        <input type="text" className="form-control" 
                        value={this.state.experience} onChange={this.onChangeExperience} required />
                    </div>
                    <div className="form-group">
                        <label><b> Email</b><span className="required-mark" style={{color:"red"}}>*</span>: </label>
                        <input type="email" className="form-control" 
                        value={this.state.email} onChange={this.onChangeEmail} required />
                    </div>
                    <div className="form-group">
                        <label><b> Contact Number</b><span className="required-mark" style={{color:"red"}}>*</span>: </label>
                        <input type="number" className="form-control" 
                        value={this.state.contactNumber} onChange={this.onChangeContactNumber} required />
                    </div>
                    <div className="form-group">
                    {/* <input type="submit" value="Post Job" className="btn btn-primary"/> &nbsp;&nbsp; */}
                    <Button type="submit" inverted color='blue'>
        Post Job
      </Button>&nbsp;&nbsp;
                    {/* <button type="button" onClick={this.clearForm} className="btn btn-danger">Clear</button> */}
                    <Button type ="button" onClick={this.clearForm} inverted color='violet'>
        Clear
      </Button>
                    </div>
                </form>
            </div>
            </div>
            </div>
        );
    }
}