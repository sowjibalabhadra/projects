import React from 'react';
import {Link} from 'react-router-dom'
import '../App.css';
import { Icon } from 'semantic-ui-react';

export default class NavBar2 extends React.Component {
    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg " style={{ backgroundColor: "#009688" }}>
                <a className="navbar-brand" href="/home" rel="noopener noreferrer" target="_blank">
            <img src='../images/logo1.png' width="50" height="60" alt="logo is missing" />
          </a>
                    <Link to="/"
                        className="navbar-brand text-light"><h2><b>YouWe-In</b></h2></Link>
   <button className="navbar-toggler" type="button" data-toggle="collapse"
          data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
          aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
                    <div className="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul className="navbar-nav mr-auto">
                            <li className="navbar-item ">
                                <Link to="/newsfeed" className="nav-link text-light"><h5><Icon
                                 className="newspaper outline" size="big"></Icon><b>Newsfeed</b></h5></Link>
                            </li>
                            <li className="navbar-item ">
                                <Link to="/addjob" className="nav-link text-light"><h5><Icon
                                 className="building" size="big"></Icon><b>Add Job</b></h5></Link>
                            </li>
                            <li className="navbar-item ">
                                <Link to="/notifications" className="nav-link text-light"><h5><Icon
                                 className="fas fa-bell-slash fa-2x" size="big"></Icon><b>Notifications</b></h5></Link>
                            </li>
                        </ul>
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link text-light" href="myprofile"><h5><Icon
                                 className="fas fa-user-circle fa-7x" size="big"></Icon><b>My Profile</b></h5></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-light" href="addprofile"><h5><Icon className="signup"
                                size="big"></Icon><b>Add Profile</b></h5></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-light" href="home"><h5><Icon className="sign-out"
                                size="big"></Icon><b>Sign Out</b></h5></a>
                            </li>
                        </ul>

                    </div>
                </nav>


            </div>

        )
    }
}