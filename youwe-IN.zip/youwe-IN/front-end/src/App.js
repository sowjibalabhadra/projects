import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import  Newsfeed  from './components/newsfeed.component';
import  Home  from './components/home.component';
import  Login  from './components/login.component';
import  Register  from './components/register.component';
// import  EditProfile from './components/edit-profile.component';
import  Addjob from './components/addjob.component';
import  Notifications from './components/notifications.component';
import Profile from './components/profile.component';
import Myprofile from './components/myprofile.component';
import Post from './components/post.component';
import SideBar from './components/sideBar.component';
import NavBar from './components/nav.component';
import EditProfile from './components/edit-profile.component';
import Clock from './components/clock.component';
import NavBar2 from './components/navBar2.component';
function App() {
  return (
     <Router>
         <Route path="/" exact component={Home} />
        <Route path="/home" exact component={Home} />        
        <Route path="/newsfeed" exact component={Newsfeed} />
        {/* <Route path="/edit/:id" component={EditTodo} /> */}
        {/* <Route path="/profile" exact component={ProfileList} /> */}
        <Route path="/myprofile" exact component={Myprofile} />
        <Route path="/addprofile" exact component={Profile} />
        <Route path="/login" component={Login} />
        <Route path="/register" exact component={Register} /> 
        <Route path="/edit-profile/:id" exact component={EditProfile}/>
 
        <Route path="/Addjob" exact component ={Addjob}/>
        {/* <Route path="/notifications" exact component = {Notifications}/> */}
        <Route path="/post" exact component ={Post}/>
        <Route path="/nav" exact component ={NavBar}/>
        <Route path="/notifications" exact component ={Notifications}/>
         <Route path="/navbar" exact component ={NavBar2}/>
        <Route path="/sidebar" exact component ={SideBar}/>

        <Clock/>
    </Router>
  );
}
export default App;
