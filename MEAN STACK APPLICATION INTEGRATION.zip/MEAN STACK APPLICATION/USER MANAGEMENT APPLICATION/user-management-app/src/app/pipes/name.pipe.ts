import { Pipe, PipeTransform } from '@angular/core';
import { User } from 'src/model/user.model';

@Pipe({
	name: 'name'
})
export class NamePipe implements PipeTransform {

	transform(usersList: any, searchText: any) {
		let updatedUsersList: User[];

		if (searchText) {
			updatedUsersList = usersList.filter(user =>
				user.firstName.toLowerCase()
					.startsWith(searchText.toLowerCase()));
			console.log(updatedUsersList.length);
			console.log(updatedUsersList);
		}
		else
			updatedUsersList = usersList;

		return updatedUsersList;
	}


}
