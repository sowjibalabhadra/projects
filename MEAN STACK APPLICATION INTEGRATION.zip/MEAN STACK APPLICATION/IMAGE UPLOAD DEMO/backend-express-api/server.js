const express = require('express');
const multer = require('multer');
const bodyParser = require('body-parser');
var mongooseDrv = require("mongoose");
const dbOpr = require('./writeToMongoDB');
const User = require('./models/user.model');
const app = express();

mongooseDrv.connect('mongodb://localhost:27017/filesDB',
  {
    useNewUrlParser: true
  });

var connection = mongooseDrv.connection;

//when connection open
connection.once('open', function () {
  console.log('Connection Open with MongoDB Server ..!');
});
//check for db error
connection.on('error', function (err) {
  console.log("Error : " + err.stack);
});

const serverPath = './public/images';

let fn;
// file uploading logic
let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, serverPath);
  },
  filename: (req, file, cb) => {
    //   cb(null, file.fieldname + '-' + Date.now() 
    //             + '.' + path.extname(file.originalname));

    // cb(null, path.parse(file.originalname).name + '-' + Date.now() 
    // + '.' + path.extname(file.originalname));

    cb(null, file.originalname);
    fn = file.originalname;
  }
});
let upload = multer({ storage: storage });

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// manually configuring cors without using cors module
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin',
    'http://localhost:4200');
  res.setHeader('Access-Control-Allow-Methods', 'POST');
  res.setHeader('Access-Control-Allow-Headers',
    'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});

// GET /api
app.get('/api', function (req, res) {
  res.end('<h1>File catcher example</h1>');
});

// POST - upload operation
app.post('/api/upload', upload.single('photo'), function (req, res) {
  if (!req.file) {
    console.log("No file received");
    return res.send({
      success: false
    });

  } else {
    console.log('file received');
    // let user = new User();
    // user.photo = JSON.stringify(req.file.buffer);
    // console.log(JSON.stringify(req.file.buffer));
    // user.save((err) => {
    //   if (err) {
    //     console.log(err.stack);
    //     return;
    //   }
    res.send({
      success: true
    })
    //})
    dbOpr.writeToDB(fn, connection, mongooseDrv);
    return res.send({
      success: true
    })
  }
});

// GET -by id
app.get('/api/:id', (req, res) => {
  let _id = req.params.id;
  User.findById(_id, { photo: 1, __v: 0 },
    function (err, user) {
      if (err) {
        res.send(err.stack);
        return;
      }
      res.json(user);
    });
});


const PORT = process.env.PORT || 3000;

app.listen(PORT, function () {
  console.log('Node.js server is running on port ' + PORT);
});
