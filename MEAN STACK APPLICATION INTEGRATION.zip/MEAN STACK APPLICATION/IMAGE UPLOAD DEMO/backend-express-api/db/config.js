// npm i mongoose gridfs-stream --save
/*
 * Connection ready state
 *
 * - 0 = disconnected
 * - 1 = connected
 * - 2 = connecting
 * - 3 = disconnecting
*/


// module.exports = connection;

//database connection string
module.exports = {
    DB: 'mongodb://127.0.0.1:27017/filesDB'
}