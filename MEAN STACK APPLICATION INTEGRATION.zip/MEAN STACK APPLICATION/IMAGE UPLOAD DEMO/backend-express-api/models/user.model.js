// STEP1: IMPORT MONGOOSE MODULE
var mongoose = require('mongoose');
// STEP2: CREATE SCHEMA OBJECT
const Schema = mongoose.Schema;

// STEP3: CREATE OUR SCHEMA WITH OPTIONALLY ADDING VALIDATIONS
let User = new Schema({
    title:{
        type:String, // unique:true, default:'noname', min:3, max:10
    },
    photo: {
        type: String
    }
});
// STEP4: EXPORT SCHEMA
module.exports = mongoose.model('User', User);