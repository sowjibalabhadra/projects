// for routes
const express = require('express');
const path = require('path');
// handling with unstructured data like images
// Multer is a node.js middleware for handling 
// multipart/form-data, which is primarily used for 
// uploading files
const multer = require('multer');
// for mongoose third party module
const mongoose = require('mongoose');
// for connection string
const config = require('../db/config');
// configuring router OR Creating an object of Router
const router = express.Router();
//import from quote.model.js Module
let User = require('../models/user.model');

// STEP3 - CONNECT MONGODB DATABASE
//Connecting Mongodb server
mongoose.connect(config.DB,
    { useNewUrlParser: true, useUnifiedTopology: true });

let db = mongoose.connection;
//when connection open
db.once('open', function () {
    console.log('Connection Open with MongoDB Server ..!');
});
//check for db error
db.on('error', function (err) {
    console.log("Error : " + err.stack);
});

const serverPath = './public/images';

var fn;
// file uploading logic
var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, serverPath);
    },
    filename: (req, file, cb) => {
        //let ext = path.extname(file.originalname);
        // var filename = `${file.originalname}-${new Date().getTime()}${ext}`;
        var filename = file.originalname;
        cb(null, filename);
        fn = filename;
        console.log(fn);
    }
});

// TESTING API
// GET /api/
router.get('/', function (req, res) {
    res.end('<h1>File catcher example</h1>');
});


router.post('/users', (req, res) => {
    var upload = multer({ storage: storage })
        .fields([{ name: 'photo', maxCount: 1 }]);

    upload(req, res, function (err) {
        if (err) {
            res.status(500).json(
                {
                    message: "Failed to upload file",
                    error: err
                });
            return;
        }
        //If upload success save user details
        var user = new User(req.body);
        // if (req.files.photo && req.files.photo.length > 0) {
        //     user.photo = `http://${req.get('host')}/public/images/${req.files.photo[0].filename}`;
        //     console.log(user.photo);
        // }
        console.log(req.body.title);
        console.log(req.body.photo);
        if (req.body.photo && req.body.photo.length > 0) {
            //user.photo = `http://${req.get('host')}/public/images/${req.files.photo[0].filename}`;
            //user.photo = `http://${req.get('host')}/public/images/${req.body.photo.filename}`;
            user.photo =
                `http://${req.get('host')}/public/images/${fn}`;
            console.log(user.photo);
        }

        user.save((err, doc) => {
            if (err) {
                res.status(500).json(
                    {
                        message: "Error in adding movie details",
                        error: err
                    });
            }
            else {
                res.status(200).json(
                    {
                        message: 'User details added successfully',
                        user: doc,
                        location: `/api/users/${doc._id}`
                    });
            }
        });
    });
});


// GET -by id
router.get('/users/:id', (req, res) => {
    console.log(req.params.id);

    User.findById(req.params.id,
        { __v: 0 }, (err, user) => {
            if (err) {
                res.status(500).json(
                    {
                        message: 'Unable to retrieve user object',
                        error: err
                    });
            } else {
                console.log(user);
                res.status(200).json(user);
            }
        });
});

// exporting all routes
module.exports = router;