// STEP1: REQUIRE DEPENDENCIES
// server creation
const express = require('express');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
//importing routes from Router File
const routeUsers = require('./routes/user.routes');

// creating the object of express()
const app = express();

// STEP2: CONFIGURE SETTING - OPTIONAL SINCE IT IS API
// configuring view engine setup

// STEP3: CONNECT TO DATABASE (OPTIONAL)
// this step is moved to user.routes.js file
// for best practice

// STEP4: DEFINE MIDDLEWARE
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static(__dirname));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname));

//Enabling CORS - CROSS ORIGIN RESOURCE SHARING
// app.use(function (req, res, next) {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header('Access-Control-Allow-Methods',
//         'PUT, GET, POST, DELETE, OPTIONS');
//     res.header("Access-Control-Allow-Headers",
//         "Origin, X-Requested-With, Content-Type, Accept");
//     next();
// });
// or
app.use(cors());


// STEP5: DEFINE ROUTES
// Default Route
app.use('/api', routeUsers);

// STEP6: START THE SERVER
const PORT = process.env.PORT || 3000;

app.listen(PORT, function () {
    console.log('Node.js server is running on port '
        + PORT);
});
