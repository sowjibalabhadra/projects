import { Component, OnInit } from '@angular/core';
import { UploadService } from 'src/app/services/upload.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  addForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private userService: UploadService) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      _id: [],
      title: [''],
      photo: ['']
    });
    // invoking service function uploadFile()
    // to upload the image asychronously
    this.userService.uploadFile();
  }

  // creating a reference object of uploader from Service Object
  uploader = this.userService.uploader;

  // onSubmit() function
  onSubmit() {
    console.log(this.addForm.value);
    this.userService.createUser(this.addForm.value)
      .subscribe(data => {
        alert(this.addForm.controls.title.value
          + ' record is added successfully ..!');

      })
  }
  path = null;
  searchById(id) {
    this.userService.getUsersById(id).subscribe(user => {
      console.log(user);
      this.path = user.photo;
      console.log(this.path);
    })
  }
}
