import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// Step3
import { FormsModule, ReactiveFormsModule} from '@angular/forms';

// Step1
// for uploading any file 
import { FileSelectDirective } from 'ng2-file-upload';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    FileSelectDirective,
    HomeComponent   // Step2
  ],
  imports: [
    BrowserModule,
    FormsModule,          // Step3
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
