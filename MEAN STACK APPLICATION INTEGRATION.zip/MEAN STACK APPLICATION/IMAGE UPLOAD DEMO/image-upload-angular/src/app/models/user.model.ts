export class User {
    _id: string;
    title: string;
    photo: string;
}