import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';

// Step5 - Import FileUploader
import { FileUploader } from 
      'ng2-file-upload/ng2-file-upload';

@Injectable({
  providedIn: 'root'
})
// Step4 Creating Service
export class UploadService {

  baseURL: string = 'http://localhost:3000/api/users';

  constructor(private http: HttpClient) { }

  // Step6 - Create the object of FileUploader
  public uploader: FileUploader =
    new FileUploader({ url: this.baseURL, 
          itemAlias: 'photo' });

  // Step7 - Upload file logic
  uploadFile() {
    this.uploader.onAfterAddingFile =
      (file) => { file.withCredentials = false; };

    this.uploader.onCompleteItem =
      (item: any, response: any,
        status: any, headers: any) => {
        console.log('ImageUpload:uploaded:', 
        item, status, response);
      }
  }

  // POST user
  createUser(user: User) {
    console.log('inservice');
    console.log(user);
    return this.http.post(this.baseURL, user);
  }

  // Get Users By Id
  getUsersById(id: string) {
    return this.http.get<User>(this.baseURL + "/" + id);
  }
}