import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductsService } from '../services/products.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private productsService: ProductsService) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({

      prodid: ['', [Validators.required]],
      custName: ['', [Validators.required, Validators.pattern("[A-Z][a-z]{2,29}")]],
      prodName: ['', Validators.required],
      description: ['', Validators.required],
      price: ['', Validators.required,],
      quantity: ['', Validators.required]


    });
  }
  onSubmit() {
    this.submitted = true;

    //If validation failed,it should return to validate again
    if (this.addForm.invalid) {
      return;
    }

    console.log(this.addForm.value);
    this.productsService.createProduct(this.addForm.value).subscribe(data => {
      this.addForm.controls.custName.value;
      Swal.fire(
        'Good Job!',
        'Your details are added!',
        'success'
      )
      this.router.navigate(['list-product']);
    })
  }
}
