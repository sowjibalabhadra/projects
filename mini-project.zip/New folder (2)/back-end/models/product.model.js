// Step 1: Import Mongoose Module
var mongoose = require('mongoose');

// Step 2: Create Schema Object
const Schema = mongoose.Schema;

// Step 3: Create our schema with optionally adding validations
let Product = new Schema({
    prodid: {
        type: String
    },
    custName: {
        type: String
    },
    prodName: {
        type: String
    },
    description: {
        type: String
    },
    price: {
        type: Number
    },
    email: {
        type: String
        // default: 'Open'
    },
    quantity: {
        type: Number
    },
});
// Step4: Export Schema 
module.exports = mongoose.model('Product', Product);